from core_video.get_video_frames import *
from core_video.write_videoframes import *

get_video_frames('Tracking.avi')
write_videoframes('New_video.avi')


